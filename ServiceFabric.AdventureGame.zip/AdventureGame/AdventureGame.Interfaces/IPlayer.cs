﻿//*********************************************************//
//    Copyright (c) Microsoft. All rights reserved.
//    
//    Apache 2.0 License
//    
//    You may obtain a copy of the License at
//    http://www.apache.org/licenses/LICENSE-2.0
//    
//    Unless required by applicable law or agreed to in writing, software 
//    distributed under the License is distributed on an "AS IS" BASIS, 
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or 
//    implied. See the License for the specific language governing 
//    permissions and limitations under the License.
//
//*********************************************************

using System.Threading.Tasks;
using Microsoft.ServiceFabric.Actors;

namespace AdventureGame.Interfaces
{
    public interface IPlayer : IActor
    {
        // Players have a name
        Task<string> Name();
        Task SetName(string name);

        // Players are located in exactly one room
        Task SetRoom(IRoom room);
        Task<IRoom> Room();

        // Unless they are dead
        Task Die();

        // A Player takes his turn by calling Play with a command
        Task<string> Play(string command);

    }
}
