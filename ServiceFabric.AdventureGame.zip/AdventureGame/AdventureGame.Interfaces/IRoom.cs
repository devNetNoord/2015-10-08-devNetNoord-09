﻿//*********************************************************//
//    Copyright (c) Microsoft. All rights reserved.
//    
//    Apache 2.0 License
//    
//    You may obtain a copy of the License at
//    http://www.apache.org/licenses/LICENSE-2.0
//    
//    Unless required by applicable law or agreed to in writing, software 
//    distributed under the License is distributed on an "AS IS" BASIS, 
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or 
//    implied. See the License for the specific language governing 
//    permissions and limitations under the License.
//
//*********************************************************

using System.Threading.Tasks;
using Microsoft.ServiceFabric.Actors;


namespace AdventureGame.Interfaces
{
    /// <summary>
    /// A room is any location in a game.
    /// </summary>
    public interface IRoom : IActor
    {
        // Rooms have a textual description
        Task<string> Description();
        Task SetDescription(string description);

        // Rooms have exits to other rooms
        Task SetExits(IRoom northRoomGrain, IRoom southRoomGrain, IRoom eastRoomGrain, IRoom westRoomGrain);
        Task<IRoom> North();
        Task<IRoom> South();
        Task<IRoom> East();
        Task<IRoom> West();

        // Players can enter or exit a room
        Task<bool> Enter(PlayerInfo player);
        Task Exit(PlayerInfo player);

        // Things can be dropped or taken from a room
        Task Drop(Thing thing);
        Task Take(Thing thing);
        Task<Thing> FindThing(string name);
    }

   

}
