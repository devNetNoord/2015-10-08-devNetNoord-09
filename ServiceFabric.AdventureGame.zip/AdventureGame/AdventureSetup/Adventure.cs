﻿//*********************************************************//
//    Copyright (c) Microsoft. All rights reserved.
//    
//    Apache 2.0 License
//    
//    You may obtain a copy of the License at
//    http://www.apache.org/licenses/LICENSE-2.0
//    
//    Unless required by applicable law or agreed to in writing, software 
//    distributed under the License is distributed on an "AS IS" BASIS, 
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or 
//    implied. See the License for the specific language governing 
//    permissions and limitations under the License.
//
//*********************************************************


using System.IO;
using System.Linq;
using System.Threading.Tasks;
using AdventureGame.Interfaces;
using Microsoft.ServiceFabric.Actors;

namespace AdventureSetup
{
    public class Adventure
    {        
        private async Task MakeRoom(string id, string description,string north, string south, string east, string west) {
            IRoomGrain roomGrain = ActorProxy.Create<IRoomGrain>(new ActorId(id), "fabric:/AdventureGameApplication");

            await roomGrain.SetDescription(description);

            IRoomGrain northRoomGrain = null;
            IRoomGrain southRoomGrain = null;
            IRoomGrain eastRoomGrain = null;
            IRoomGrain westRoomGrain = null;

            if (north!="")
                northRoomGrain = ActorProxy.Create<IRoomGrain>(new ActorId(north), "fabric:/AdventureGameApplication");

            if (south != "")
                southRoomGrain = ActorProxy.Create<IRoomGrain>(new ActorId(south), "fabric:/AdventureGameApplication");

            if (east != "")
                eastRoomGrain = ActorProxy.Create<IRoomGrain>(new ActorId(east), "fabric:/AdventureGameApplication");

            if (west != "")
                westRoomGrain = ActorProxy.Create<IRoomGrain>(new ActorId(west), "fabric:/AdventureGameApplication");

            await roomGrain.SetExits(northRoomGrain, southRoomGrain, eastRoomGrain, westRoomGrain);
        }

        private async Task MakeThing(string id, string name, string room)
        {
            Thing thing = new Thing();
            thing.Name = name;
            IRoomGrain roomGrain = ActorProxy.Create<IRoomGrain>(new ActorId(room), "fabric:/AdventureGameApplication");
            await roomGrain.Drop(thing);
        }
        public async Task Configure(string filename)
        {
            string line;

            StreamReader file = new StreamReader(filename);
            while ((line = file.ReadLine()) != null)
            {
                if (!line.StartsWith(";")) // Skip comment lines
                {
                    var fields = line.Split('|').Select(s => s.Trim().ToLower()).ToArray();

                    switch (fields[0])
                    {
                        case "room":
                            await MakeRoom(fields[1], fields[2], fields[3], fields[4], fields[5], fields[6]);
                            break;
                        case "thing":
                            await MakeThing(fields[1], fields[2], fields[3]);
                            break;
                    }
                }
            }

            file.Close();
        }
    }
}
