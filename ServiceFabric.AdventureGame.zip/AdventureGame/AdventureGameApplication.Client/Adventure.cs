﻿//*********************************************************//
//    Copyright (c) Microsoft. All rights reserved.
//    
//    Apache 2.0 License
//    
//    You may obtain a copy of the License at
//    http://www.apache.org/licenses/LICENSE-2.0
//    
//    Unless required by applicable law or agreed to in writing, software 
//    distributed under the License is distributed on an "AS IS" BASIS, 
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or 
//    implied. See the License for the specific language governing 
//    permissions and limitations under the License.
//
//*********************************************************


using System.IO;
using System.Linq;
using System.Threading.Tasks;
using AdventureGame.Interfaces;
using Microsoft.ServiceFabric.Actors;

namespace AdventureGame.Client
{
    public class Adventure
    {
        private async Task MakeRoom(string id, string description, string north, string south, string east, string west)
        {
            IRoom room = ActorProxy.Create<IRoom>(new ActorId(id), "fabric:/AdventureGameApplication");

            await room.SetDescription(description);

            IRoom northRoom = null;
            IRoom southRoom = null;
            IRoom eastRoom = null;
            IRoom westRoom = null;

            if (north != "")
                northRoom = ActorProxy.Create<IRoom>(new ActorId(north), "fabric:/AdventureGameApplication");

            if (south != "")
                southRoom = ActorProxy.Create<IRoom>(new ActorId(south), "fabric:/AdventureGameApplication");

            if (east != "")
                eastRoom = ActorProxy.Create<IRoom>(new ActorId(east), "fabric:/AdventureGameApplication");

            if (west != "")
                westRoom = ActorProxy.Create<IRoom>(new ActorId(west), "fabric:/AdventureGameApplication");

            await room.SetExits(northRoom, southRoom, eastRoom, westRoom);
        }

        private async Task MakeThing(string id, string name, string roomid)
        {
            Thing thing = new Thing();
            thing.Name = name;
            IRoom room = ActorProxy.Create<IRoom>(new ActorId(roomid), "fabric:/AdventureGameApplication");
            if (room.FindThing(name) == null)
            {
                await room.Drop(thing);
            }
        }

        public async Task Configure(string filename)
        {
            string line;

            StreamReader file = new StreamReader(filename);
            while ((line = file.ReadLine()) != null)
            {
                if (!line.StartsWith(";")) // Skip comment lines
                {
                    var fields = line.Split('|').Select(s => s.Trim().ToLower()).ToArray();

                    switch (fields[0])
                    {
                        case "room":
                            await MakeRoom(fields[1], fields[2], fields[3], fields[4], fields[5], fields[6]);
                            break;
                        case "thing":
                            await MakeThing(fields[1], fields[2], fields[3]);
                            break;
                    }
                }
            }

            file.Close();
        }
    }
}
