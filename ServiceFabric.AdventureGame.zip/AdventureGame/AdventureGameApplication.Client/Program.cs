﻿//*********************************************************//
//    Copyright (c) Microsoft. All rights reserved.
//    
//    Apache 2.0 License
//    
//    You may obtain a copy of the License at
//    http://www.apache.org/licenses/LICENSE-2.0
//    
//    Unless required by applicable law or agreed to in writing, software 
//    distributed under the License is distributed on an "AS IS" BASIS, 
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or 
//    implied. See the License for the specific language governing 
//    permissions and limitations under the License.
//
//*********************************************************

using AdventureGame.Interfaces;
using Microsoft.ServiceFabric.Actors;
using System;

namespace AdventureGame.Client
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine(@"
  ___      _                 _                  
 / _ \    | |               | |                 
/ /_\ \ __| |_   _____ _ __ | |_ _   _ _ __ ___ 
|  _  |/ _` \ \ / / _ \ '_ \| __| | | | '__/ _ \
| | | | (_| |\ V /  __/ | | | |_| |_| | | |  __/
\_| |_/\__,_| \_/ \___|_| |_|\__|\__,_|_|  \___|");

            Console.WriteLine();

            Console.WriteLine("Setting up Adventure, please wait ...");
            Adventure adventure = new Adventure();
            adventure.Configure("AdventureConfig.txt").Wait();
            Console.WriteLine("Adventure setup completed.");
            Console.WriteLine();

            Console.WriteLine("What's your name?");
            string name = Console.ReadLine();
        
            var player = ActorProxy.Create<IPlayer>(new ActorId(name), "fabric:/AdventureGameApplication");
            player.SetName(name).Wait();

            Console.WriteLine(string.Format("You are playing on partition {0}", player.GetActorId().GetPartitionKey().ToString()));

            
            var roomId = new ActorId("west-of-house");
            var room1 = ActorProxy.Create<IRoom>(roomId, "fabric:/AdventureGameApplication");
            player.SetRoom(room1).Wait();

            Console.WriteLine(player.Play("look").Result);

            string result = "Start";

            try
            {
                while (result != "")
                {
                    string command = Console.ReadLine();

                    result = player.Play(command).Result;
                    Console.WriteLine(result);

                    if (result == "stop")
                    {
                        player.Die().Wait();
                        result = "";
                    }
                }
            }
            catch
            {
                player.Die().Wait();
            }
        }
    }

}
