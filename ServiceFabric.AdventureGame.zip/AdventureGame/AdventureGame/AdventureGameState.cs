﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using AdventureGame.Interfaces;
using Microsoft.ServiceFabric;
using Microsoft.ServiceFabric.Actors;

namespace AdventureGame
{
    [DataContract]
    public class PlayerState
    {
        [DataMember]
        public string name;

        [DataMember]
        public IRoom room;

        [DataMember]
        public List<Thing> things = new List<Thing>();

        public override string ToString()
        {
            return string.Format(CultureInfo.InvariantCulture, "AdventureGameState[Name = {0}]", name);
        }
    }


    [DataContract]
    public class RoomState
    {
        [DataMember]
        public List<PlayerInfo> players = new List<PlayerInfo>();
        [DataMember]
        public List<Thing> things = new List<Thing>();

        [DataMember]
        public IRoom north = null;
        [DataMember]
        public IRoom south = null;
        [DataMember]
        public IRoom east = null;
        [DataMember]
        public IRoom west = null;

        public override string ToString()
        {
            return string.Format(CultureInfo.InvariantCulture, "RoomState");
        }
    }
}