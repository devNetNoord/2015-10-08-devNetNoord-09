﻿//*********************************************************//
//    Copyright (c) Microsoft. All rights reserved.
//    
//    Apache 2.0 License
//    
//    You may obtain a copy of the License at
//    http://www.apache.org/licenses/LICENSE-2.0
//    
//    Unless required by applicable law or agreed to in writing, software 
//    distributed under the License is distributed on an "AS IS" BASIS, 
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or 
//    implied. See the License for the specific language governing 
//    permissions and limitations under the License.
//
//*********************************************************


using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.ServiceFabric.Actors;
using AdventureGame.Interfaces;

namespace AdventureGame
{
    public class Player : Actor<PlayerState>, IPlayer
    {

        Task<string> IPlayer.Name()
        {
            return Task.FromResult(this.State.name);
        }

        Task<IRoom> IPlayer.Room()
        {
            return Task.FromResult(this.State.room);
        }


        Task IPlayer.Die()
        {
            foreach (var thing in this.State.things)
                this.Drop(thing);

            string myKeyExt = this.Id.ToString();
            var myInfo = new PlayerInfo { Key = myKeyExt, Name = this.State.name };

            this.State.room.Exit(myInfo);
            return Task.FromResult(true);
        }

        async Task<string> Drop(Thing thing)
        {
            if (thing != null) 
            {
                this.State.things.Remove(thing);
                await this.State.room.Drop(thing);
                return "Okay.";
            }
            else
                return "I don't understand.";
        }

        async Task<string> Take(Thing thing)
        {
            if (thing != null) 
            {
                this.State.things.Add(thing);
                await this.State.room.Take(thing);
                return "Okay.";
            }
            else
                return "I don't understand.";
        }


        Task IPlayer.SetName(string name)
        {
            this.State.name = name;
            return Task.FromResult(true);
        }

        Task IPlayer.SetRoom(IRoom room)
        {
            if (this.State.room == null)
            {  
            this.State.room = room;
            string myKeyExt = this.Id.ToString();
            return room.Enter(new PlayerInfo { Key = myKeyExt, Name = this.State.name });
            }
            return Task.FromResult(true);
        }

        async Task<string> Go(string direction)
        {
            IRoom destination = null;

            switch (direction)
            {
                case "north":
                    destination = await this.State.room.North();
                    break;
                case "south":
                    destination = await this.State.room.South();
                    break;
                case "east":
                    destination = await this.State.room.East();
                    break;
                case "west":
                    destination = await this.State.room.West();
                    break;
                default:
                    return "I don't understand.";
            }

            string myKeyExt = this.Id.ToString();
            var myInfo = new PlayerInfo { Key = myKeyExt, Name = this.State.name };

            var description = "You cannot go in that direction.";

            if (destination != null)
            {
                //await this.State.room.Exit(myInfo);
                //await destination.Enter(myInfo);
                if (destination.Enter(myInfo).Result)
                {
                    await this.State.room.Exit(myInfo);
                    this.State.room = destination;
                    description = await destination.Description();
                }
                else
                {
                    description = description + " Room is full.";
                }
            }
            return description;
        }

        private string RemoveStopWords(string s)
        {
            string[] stopwords = new string[] { " on ", " the ", " a " };

            StringBuilder sb = new StringBuilder(s);
            foreach (string word in stopwords)
            {
                sb.Replace(word, " ");
            }

            return sb.ToString();
        }

        private Thing FindMyThing(string name)
        {
            return this.State.things.Where(x => x.Name == name).FirstOrDefault();
        }

        private string Rest(string[] words)
        {
            StringBuilder sb = new StringBuilder();

            for (int i = 1; i < words.Length; i++)
                sb.Append(words[i] + " ");

            return sb.ToString().Trim().ToLower();
        }

        async Task<string> IPlayer.Play(string command)
        {
            Thing thing;
            command = RemoveStopWords(command);

            string[] words = command.Split(' ');

            string verb = words[0];

            switch (verb)
            {
                case "look":
                    return await this.State.room.Description();

                case "go":
                    return await Go(words[1]);

                case "drop":
                    thing = FindMyThing(Rest(words));
                    return await Drop(thing);

                case "take":
                    thing = await this.State.room.FindThing(Rest(words));
                    return await Take(thing);

                case "inv":
                case "inventory":
                    
                    return "you Have " + string.Join(" ", this.State.things.Select( x => x.Name));

                case "end":
                    return "";

                    

            }
            return "I don't understand.";
        }
    }
}
