﻿//*********************************************************//
//    Copyright (c) Microsoft. All rights reserved.
//    
//    Apache 2.0 License
//    
//    You may obtain a copy of the License at
//    http://www.apache.org/licenses/LICENSE-2.0
//    
//    Unless required by applicable law or agreed to in writing, software 
//    distributed under the License is distributed on an "AS IS" BASIS, 
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or 
//    implied. See the License for the specific language governing 
//    permissions and limitations under the License.
//
//*********************************************************

using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.ServiceFabric.Actors;
using AdventureGame.Interfaces;

namespace AdventureGame
{
    public class Room : Actor<RoomState>, IRoom
    {

        private string description;



        Task<bool> IRoom.Enter(PlayerInfo player)
        {
            //if (this.State.players.Count>=2)
            //    return Task.FromResult(false);

            this.State.players.Add(player);
            return Task.FromResult(true);
        }

        Task IRoom.Exit(PlayerInfo player)
        {
            PlayerInfo pInfo = null;

            foreach (var p in this.State.players)
            {
                if (p.Key == player.Key)
                {
                    pInfo = p;
                    break;
                }
            }

            if ( pInfo != null)
                this.State.players.Remove(pInfo);
            return Task.FromResult(true);
        }

        Task IRoom.Drop(Thing thing)
        {
            this.State.things.Add(thing);
            return Task.FromResult(true);
        }

        Task IRoom.Take(Thing thing)
        {
            this.State.things.Remove(thing);
            return Task.FromResult(true);
        }

        Task IRoom.SetDescription(string description)
        {
            this.description = description;
            return Task.FromResult(true);
        }

        Task IRoom.SetExits(IRoom north, IRoom south, IRoom east, IRoom west)
        {
            this.State.north = north;
            this.State.south = south;
            this.State.east = east;
            this.State.west = west;
            return Task.FromResult(true);
        }


        Task<Thing> IRoom.FindThing(string name)
        {
            return Task.FromResult(this.State.things.Where(x => x.Name == name).FirstOrDefault());
        }

        async Task<string> IRoom.Description()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine(this.description);
            
            sb.Append(" Exits to the ");

            if (this.State.north != null) sb.Append("north ");
            if (this.State.south != null) sb.Append("south ");
            if (this.State.east != null) sb.Append("east ");
            if (this.State.west != null) sb.Append("west ");

            sb.AppendLine();

            if (this.State.things.Count > 0)
            {
                sb.AppendLine(" The following items are present:");
                foreach (var thing in this.State.things)
                {
                    sb.AppendLine(thing.Name);
                }
            }

            if (this.State.players.Count > 1)
            {
                sb.AppendLine("The following players are present:");
                foreach (var player in this.State.players)
                {
                    sb.AppendLine(player.Name);
                }
            }

            return sb.ToString();
        }


        Task<IRoom> IRoom.North()
        {
            return Task.FromResult(this.State.north);
        }

        Task<IRoom> IRoom.South()
        {
            return Task.FromResult(this.State.south);
        }

        Task<IRoom> IRoom.East()
        {
            return Task.FromResult(this.State.east);
        }

        Task<IRoom> IRoom.West()
        {
            return Task.FromResult(this.State.west);
        }
    }
}
